import React from 'react';
import WelcomeContent4 from '../components/welcome4';
import Services1 from '../components/Services';
import Testmonials from '../components/Testimonials';


const Services = () => {
    return (
        <>
        <WelcomeContent4 />
        <Services1 />
        <Services1 />
        <Testmonials />
        </>

    )
}
export default Services