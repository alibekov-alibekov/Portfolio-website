import React from 'react';
import Inputs from '../components/inputs';
import WelcomeContent6 from '../components/welcome6';

const Contact = () => {
    return (
        <>
        <WelcomeContent6 />
        <Inputs />
        </>

    )
}
export default Contact