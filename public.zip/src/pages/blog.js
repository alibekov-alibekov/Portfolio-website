import React from 'react';
import Cards from '../components/cards';
import WelcomeContent5 from '../components/welocme5';

const Blog = () => {
    return (
        <>
        <WelcomeContent5 />
        <Cards />
        </>

    )
}
export default Blog