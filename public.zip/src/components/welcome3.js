import { Col, Container, Row } from "reactstrap";


const WelcomeContent3 = () => {
    return (
        <div className='header'>
        <Container >
            <Row>
                <Col className='p-5 text-center'>
                    <div className='  header-lorem-div '>
                         <p className='display-2 fw-bolder defaultColor'>About Us</p>
                         <p className='mb-5' >Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque autem nulla quos suscipit laborum fugit aspernatur rem pariatur illo. </p>    
                        
                      </div>
               
               
                </Col>  
            </Row>
        </Container>
        </div>
    )
}

export default WelcomeContent3;